package comp2402a1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Part10 {
	
	/**
	 * Your code goes here - see Part0 for an example
	 * @param r the reader to read from
	 * @param w the writer to write to
	 * @throws IOException
	 */
	public static void doIt(BufferedReader r, PrintWriter w) throws IOException {
		List<String> aList = new ArrayList<>();
		String max = "";

		String line;
		while ((line = r.readLine()) != null) {
			aList.add(line);
		}

		for ( int i = 1; i < aList.size(); i++ ) {
			for (int j = 0; j < i; j++) {
				int compare = aList.get(i).compareTo(aList.get(j));
				int compare2 = aList.get(i).compareTo(aList.get(j)+1);
				if (compare > 0 && compare2 <0) {
					aList.set(i, aList.get(j) + 1);
				}
			}
		}

		for ( int i = 0; i < aList.size(); i++ ) {
			int compare3 = max.compareTo(aList.get(i));
			if (compare3 < 0) {
				max = aList.get(i);
				w.println(max);
			}
		}

	}

	/**
	 * The driver.  Open a BufferedReader and a PrintWriter, either from System.in
	 * and System.out or from filenames specified on the command line, then call doIt.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			BufferedReader r;
			PrintWriter w;
			if (args.length == 0) {
				r = new BufferedReader(new InputStreamReader(System.in));
				w = new PrintWriter(System.out);
			} else if (args.length == 1) {
				r = new BufferedReader(new FileReader(args[0]));
				w = new PrintWriter(System.out);				
			} else {
				r = new BufferedReader(new FileReader(args[0]));
				w = new PrintWriter(new FileWriter(args[1]));
			}
			long start = System.nanoTime();
			doIt(r, w);
			w.flush();
			long stop = System.nanoTime();
			System.out.println("Execution time: " + 10e-9 * (stop-start));
		} catch (IOException e) {
			System.err.println(e);
			System.exit(-1);
		}
	}
}
