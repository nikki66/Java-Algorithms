package comp2402a2;
import java.util.ArrayList;
import java.util.List;


/**
 */
public class Tester {
	public static boolean testPart1(List<Integer> ell) {
		Boolean checker = false;
		int K = 100000;
		Stopwatch s = new Stopwatch();

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.add(i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.add(0, i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}


		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.add(ell.size()/2, i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.get(i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}
		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.set(i,0);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.remove(ell.size()-1);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}


		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.remove(0);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}


		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.remove(ell.size()/2);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}


		//Correctness
		if(ell.size() != 0){
			checker =false;
		}else{
			checker = true;
		}

		return checker;
	}

	public static boolean testPart2(List<Integer> ell) {

		int K = 100000;
		Stopwatch s = new Stopwatch();
		Boolean checker = false;

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.add(i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}


		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.add(0, i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.get(i);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}

		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.set(i,0);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}



		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.remove(ell.size()-1);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}


		System.out.flush();
		s.start();
		for (int i = 0; i < K; i++) {
			ell.remove(0);
		}
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}

		/*System.out.flush();
		s.start();
		ell.size();
		s.stop();
		if(s.elapsedSeconds() < 2){
			checker = true;
		}*/

		//Correctness
		if(ell.size() != 0){
			checker =false;
		}else{
			checker = true;
		}

		return checker;
	}
	public static boolean testPart3(AbstractTable<Integer> ell) {
		Stopwatch s = new Stopwatch();
		Boolean checker = false;
		int nrows = 9, ncols = 6;
		int row =0;
		int col =0;

		//efficiency
		s.start();
		for (int i = 0; i < ncols; i++) {
			ell.addCol(ell.cols());
			col++;
		}
		s.stop();
		if (s.elapsedSeconds() < 2) {
			checker = true;
		}

		s.start();
		for (int i = 0; i < nrows; i++) {
			ell.addRow(ell.rows());
			row++;
		}
		s.stop();
		if (s.elapsedSeconds() < 2) {
			checker = true;
		}

		s.start();
		for (int i = 1; i <= nrows; i++) {
			ell.set(i - 1, (i - 1) % ell.cols(), 1111 * i);

		}
		s.stop();
		if (s.elapsedSeconds() < 2) {
			checker = true;
		}

		s.start();
		ell.addCol(2);
		col++;
		s.stop();
		if (s.elapsedSeconds() < 2) {
			checker = true;
		}

		s.start();
		ell.addRow(3);
		row++;
		s.stop();
		if (s.elapsedSeconds() < 2) {
			checker = true;
		}

		//correctness
		ell.addCol(2);
		col++;
		ell.addRow(3);
		row++;
		ell.addCol(2);
		col++;
		ell.addRow(3);
		row++;
		ell.addCol(2);
		col++;
		ell.addRow(3);
		row++;

		if(ell.cols() == col){
			checker = true;

		}else{
			checker=false;
		}
		if(ell.rows() == row){
			checker = true;

		}else{
			checker=false;
		}




		return checker;
	}

}
