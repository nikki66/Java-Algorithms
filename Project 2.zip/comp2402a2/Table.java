package comp2402a2;
import java.util.ArrayList;
import java.util.List;

/**
 */
public class Table<T> implements AbstractTable<T> {
	/**
	 * You decide on the instance variables you need.
	 */
	List<List<T>> matrix;
	int row2;
	int col2;


	public Table(Class<T> t) {
		matrix = new ArrayList<List<T>>();
		row2 =0;
		col2 =0;
	}

	public int rows() {
/*		if ( matrix.size() > 0 ){
			return matrix.get(0).size();}
		else{
			return 0;}*/
		return row2;

	}

	public int cols() {
		//return matrix.size();
		return col2;
	}

	public T get(int i, int j) {
		if (i < 0 || i > rows() - 1 || j < 0 || j > cols()-1)
			throw new IndexOutOfBoundsException();
		return matrix.get(j).get(i);

	}

	public T set(int i, int j, T x) {
		if (i < 0 || i > rows() - 1 || j < 0 || j > cols()-1)
			throw new IndexOutOfBoundsException();
		T old = matrix.get(j).get(i);
		matrix.get(j).set(i, x);
		return old;

	}

	public void addRow(int i) {
		if (i < 0 || i > rows()) throw new IndexOutOfBoundsException();
		if (cols() >= 0) {
			for (int j = 0; j < cols(); j++) {
				matrix.get(j).add(i, null);
			}
			row2++;
		}

	}

	public void removeRow(int i) {
		if (i < 0 || i > rows() - 1) throw new IndexOutOfBoundsException();
		for(int j = 0; j < cols(); j++){
			matrix.get(j).remove(i);

		}
		row2--;

	}

	public void addCol(int j) {
		if (j < 0 || j > cols()) throw new IndexOutOfBoundsException();
		List<T> newCol= new ArrayList<T>();
		for ( int i = 0; i < rows(); i++ ) {
			newCol.add(null);


		}
		matrix.add(j, newCol);
		col2++;

	}

	public void removeCol(int j) {
		if (j < 0 || j > cols() - 1) throw new IndexOutOfBoundsException();
		matrix.remove(j);
		col2--;

	}
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < rows(); i++) {
			for (int j = 0; j < cols(); j++) {
				sb.append(String.valueOf(get(i, j)));
				sb.append(" ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	/* Here is the expected output from this main function:
		1111 null null null null null
		null 2222 null null null null
		null null 3333 null null null
		null null null 4444 null null
		null null null null 5555 null
		null null null null null 6666
		7777 null null null null null
		null 8888 null null null null
		null null 9999 null null null

		1111 null null null null null null
		null 2222 null null null null null
		null null null 3333 null null null
		null null null null null null null
		null null null null 4444 null null
		null null null null null 5555 null
		null null null null null null 6666
		7777 null null null null null null
		null 8888 null null null null null
		null null null 9999 null null null
	*/
	public static void main(String[] args) {
		int nrows = 9, ncols = 6;
		Table<Integer> t = new Table<Integer>(Integer.class);

		for (int i = 0; i < ncols; i++) {
			t.addCol(t.cols());
		}
		for (int i = 0; i < nrows; i++) {
			t.addRow(t.rows());
		}

		for (int i = 1; i <= nrows; i++) {
			t.set(i-1, (i-1)%t.cols(), 1111*i);

		}
		System.out.println(t.toString());
		t.addCol(2);
		t.addRow(3);
		System.out.println(t.toString());
	}
}
