package comp2402a4;
import java.util.*;

public class GeometricTree extends BinaryTree<GeometricTreeNode> {

	public GeometricTree() {
		super (new GeometricTreeNode());
	}

	public void inorderDraw() {
		assignLevels();
		// TODO: use your code here instead
		//Random rand = new Random();
		//randomX(r, rand);
		GeometricTreeNode aNode;
		int n=0;
		aNode= firstNode();
		while(true){
			if(aNode==nil){
				break;
			}else{
				aNode.position.x= n;
				n = n+1;
				aNode = nextNode(aNode);
			}
		}
	}

	protected void randomX(GeometricTreeNode u, Random r) {
		if (u == null) return;
		u.position.x = r.nextInt(60);
		randomX(u.left, r);
		randomX(u.right, r);
	}


	/**
	 * Draw each node so that it's x-coordinate is as small
	 * as possible without intersecting any other node at the same level
	 * the same as its parent's
	 */
	public void leftistDraw() {
		assignLevels();
		/*Random rand = new Random();
		randomX(r, rand);*/

		//Code provided from Profs notes (bfTraverse)
		Queue<GeometricTreeNode> q = new LinkedList<GeometricTreeNode>();
		if (r != nil) q.add(r);
		GeometricTreeNode node;
		node = this.r;

		while (q.size() != 0) {
			GeometricTreeNode u = q.remove();
			if (u.left != nil) q.add(u.left);
			if (u.right != nil) q.add(u.right);

			//added to the code
			int firstY = node.position.y ;
			int secondY = u.position.y;
			int firstX = node.position.x;

			if(firstY != secondY){
				u.position.x = 0;
				node = u;
			}else{
				u.position.x = increment(firstX);
				node = u;
			}
		}
		if(q.size() == 0){
			r.position.x = 0;
		}
	}

	Map<GeometricTreeNode, Integer> theMap;
	int length = 0;


	public void balancedDraw() {
		assignLevels();
		/*Random rand = new Random();
		randomX(r, rand);*/
		assignLevels();

		theMap = aMap(r);
		positionChild(r);
		length = 0;

	}
	public void positionChild(GeometricTreeNode n){
		positionChildRecursion(n,0,0);
	}
	public void positionChildRecursion(GeometricTreeNode node, int xcoor, int ycoor) {
		if (node != nil) {
			if (xcoor > length) {
				length = xcoor;
			}
			node.position.x = xcoor;
			node.position.y = ycoor;

			if (!(node.left == nil || node.right != nil)) {
				this.positionChildRecursion(node.left, increment(length), ycoor);
			} else {
				if (!(node.left == nil || node.right == nil)) {
					if (theMap.get(node.left) <= theMap.get(node.right)) {
						this.positionChildRecursion(node.left, xcoor, increment(ycoor));
						this.positionChildRecursion(node.right, increment(length), ycoor);
					} else {
						this.positionChildRecursion(node.right, xcoor, increment(ycoor));
						this.positionChildRecursion(node.left, increment(length), ycoor);
					}
				} else {
					this.positionChildRecursion(node.right, increment(length), ycoor);
				}

			}
		}else {
			return;
		}
	}

	//similar to traverse2() from prof notes
	public HashMap<GeometricTreeNode, Integer> aMap(GeometricTreeNode n) {
		GeometricTreeNode past = nil;
		GeometricTreeNode next;

		HashMap<GeometricTreeNode, Integer> tree = new HashMap<GeometricTreeNode, Integer>();
		while(true){
			if(n==nil){
				break;
			}else{
				boolean pastParent = (n.parent == past);
				boolean checkLeft = (n.left != nil);
				boolean checkRight = (n.right != nil);
				boolean pastLeft = (n.left == past);

				if(pastParent){
					if(checkLeft){
						next = n.left;
					}else if (checkRight){
						next = n.right;
					}else {
						tree.put(n,checker(n,tree));
						next = n.parent;
					}
				}else if(pastLeft){
					if(checkRight){
						next = n.right;
					}else {
						tree.put(n,checker(n,tree));
						next = n.parent;
					}
				}else {
					tree.put(n,checker(n,tree));
					next = n.parent;
				}

				past = n;
				n = next;

			}
		}

		return tree;
	}
	private int checker (GeometricTreeNode n, HashMap<GeometricTreeNode,Integer> aHash){
		int number=0;
		if(n.left != nil){
			number = aHash.get(n.left);
		}
		else {
			number =1;
		}
		if(n.right !=null){
			number += aHash.get(n.right);
		}
		else {
			number+=1;
		}
		return increment(number);
	}
	private int increment(int n){ return n+1; }


	protected void assignLevels() {
		assignLevels(r, 0);
	}

	protected void assignLevels(GeometricTreeNode u, int i) {
		if (u == null) return;
		u.position.y = i;
		assignLevels(u.left, i+1);
		assignLevels(u.right, i+1);
	}

	public static void main(String[] args) {
		GeometricTree t = new GeometricTree();
		galtonWatsonTree(t, 100);
		System.out.println(t);
		t.inorderDraw();
		System.out.println(t);
	}

}
